
const el = document.createElement('h2')
el.textContent = 'Script executed'
document.body.append(el)
